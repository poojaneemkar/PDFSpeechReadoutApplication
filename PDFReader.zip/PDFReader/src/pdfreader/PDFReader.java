package pdfreader;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfImportedPage;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import java.io.File;
import javax.speech.Central;
import javax.speech.synthesis.Synthesizer;
import javax.speech.synthesis.SynthesizerModeDesc;
import java.util.Locale;



public class PDFReader {
 public static String str;
    /**
     * @param args the command line arguments
     */
 //   private static String INPUTFILE = "D:/AbstractsPrjcse-2013-14.pdf"; //Specifying the file location.
   public static void main(String[] args) {
        try {
        	String pdf_path = PDFSelector.s;
        	 str=null;
        PdfReader reader = new PdfReader(pdf_path);
        int n = reader.getNumberOfPages();
      for(int i=1;i<=n;i++){
   str=PdfTextExtractor.getTextFromPage(reader, i); //Extracting the content from a particular page.
   
            System.out.println(str);
			 try {
              System.setProperty("freetts.voices",
		   "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory");
		   
		  Central.registerEngineCentral
		   ("com.sun.speech.freetts.jsapi.FreeTTSEngineCentral");
		  Synthesizer  synthesizer =
		   Central.createSynthesizer(new SynthesizerModeDesc(Locale.US));
		  synthesizer.allocate();
		  synthesizer.resume();
		  synthesizer.speakPlainText(str, null);
		  synthesizer.waitEngineState(Synthesizer.QUEUE_EMPTY);
		 // synthesizer.deallocate();
            }        
        catch(Exception e2)
         {
            System.out.println("Exception : "+e2.toString());
        }
       
      }
        }
        catch (Exception e) {
            System.out.println(e);
        }
        
    }

}